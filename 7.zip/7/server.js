const express = require('express');
const puppeteer = require('puppeteer');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware pour parser le JSON et les URL encodées
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serveur de fichiers statiques
app.use(express.static(path.join(__dirname, 'public')));

// Route pour générer le PDF
app.post('/generer-pdf', async (req, res) => {
    const { contenu } = req.body;

    try {
        const browser = await puppeteer.launch();
        const page = await browser.newPage();

        // Création du contenu HTML pour le PDF
        const content = `
            <!DOCTYPE html>
            <html lang="fr">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Document PDF</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        color: #333;
                        background-color: #fff;
                        padding: 20px;
                    }
                    h1 {
                        color: #007bff;
                    }
                    p {
                        margin-bottom: 10px;
                    }
                    /* Ajoutez d'autres styles CSS au besoin */
                </style>
            </head>
            <body>
                ${contenu}
            </body>
            </html>
        `;

        await page.setContent(content);
        const pdf = await page.pdf({ format: 'A4' });

        await browser.close();
    
        res.contentType('application/pdf');
        res.send(pdf);
    } catch (error) {
        console.error('Erreur lors de la génération du PDF :', error);
        res.status(500).send('Une erreur est survenue lors de la génération du PDF.');
    }
});

// Démarrer le serveur
app.listen(PORT, () => {
    console.log(`Serveur démarré sur le port ${PORT}`);
});